import gpxpy
#import datetime as dt
from math import radians,sqrt, tan, atan, cos, sin, atan2, degrees
import matplotlib.pyplot as plt
import pylab
from datetime import timedelta #datetime,
import numpy

from kivy.app import App  
from kivy.uix.boxlayout import BoxLayout  
from kivy.properties import ObjectProperty  
from kivy.garden.mapview import MapMarker, MarkerMapLayer
import matplotlib.pyplot as plt

class TestForm(BoxLayout):
    my_map=ObjectProperty()
    odleglosc=ObjectProperty()
    predkosc=ObjectProperty()
    wys_min=ObjectProperty()
    wys_max=ObjectProperty()
    przewy_suma=ObjectProperty()
    przewy_gora=ObjectProperty()
    przewy_dol=ObjectProperty()
    czas_ostateczny=ObjectProperty()
    nachylmax=ObjectProperty()
    
    def analyse_file(self):
        self.draw_route(lon,lat)
        self.wys_min.text="{:.3f}".format(wysokosc_min)
        self.wys_max.text="{:.3f}".format(wysokosc_max)
        self.odleglosc.text="{:.3f}".format(suma)
        self.przewy_suma.text="{:.3f}".format(Przewyzszenie_suma)
        self.przewy_gora.text="{:.3f}".format(Przewyzszenia_góra_suma)
        self.przewy_dol.text="{:.3f}".format(Przewyzszenia_dół_suma)
        self.czas_ostateczny.text="{}".format(czas_ostateczny)
        self.predkosc.text="{:.3f}".format(sr_predkosc)
        self.nachylmax.text="{:.3f}".format(HARDCORE)             

    # Rysuje sciezke
    def draw_route(self,lon,lat):
        data_layer = MarkerMapLayer()
        self.my_map.add_layer(data_layer)
        for point in zip(lat,lon):
            self.mark_point(*point, layer=data_layer)
            
    def mark_point(self, lat, lon,layer=None):
        if lat != None and lon != None:
            marker= MapMarker(lat=lat, lon=lon)
            self.my_map.add_marker(marker=marker, layer=layer)
               

lat = []
lon = []
el = []
dates = []
gpx_file = open('gpx/krk2.gpx', "r") # podac sciezke do pliku
gpx = gpxpy.parse(gpx_file)
gpx_file.close()
for track in gpx.tracks:
    for seg in track.segments:
        for point in seg.points:
#                lam.append(point.longitude)
#                fi.append(point.latitude)
#                # jezeli informacja o elewacji dostepna
#                el.append(point.elevation)
                # jezeli informacja o czasie dostepna
                # usuniecie informacji o strefie czasowej
    #            point.time = point.time.replace(tzinfo=None)
    #            dates.append(point.time)
            lon.append(point.longitude)
            lat.append(point.latitude)
            point.time = point.time.replace(tzinfo=None)
            dates.append(point.time)
            el.append(point.elevation)   
            
    
    lat2=lat[1:]
    lon2=lon[1:]
    
    a = 6378137.000;
    e2= 0.00669438002290;
    b=a*sqrt(1-e2);
    f=1-(b/a);
    lat2=lat[1:]
    lon2=lon[1:]
    odl2=[]
    for (i,j,q,w) in zip(lon,lon2,lat,lat2):
        delta_lambda=radians(j-i)
        delta_fii=radians(w-q)
        if delta_lambda==0 and delta_fii==0:
               S=float(0)
               print(0)
        else:
            Ua=atan((1-f)*tan(radians(q)))
            Ub=atan((1-f)*tan(radians(w)))
            L=delta_lambda;
            iteracja=0
            k=1
            #PETLA:
            while k > (0.000001/206265):
                iteracja=iteracja+1
                l=L      
                sin_sigma=sqrt((cos(Ub)*sin(L))**2+(cos(Ua)*sin(Ub)-sin(Ua)*cos(Ub)*cos(L))**2);
                cos_sigma=(sin(Ua)*sin(Ub))+ (cos(Ua)*cos(Ub)*cos(L));
                sigma=atan2(sin_sigma,cos_sigma);        
                sin_alfa=(cos(Ua)*cos(Ub)*sin(L))/sin_sigma;
                cos_alfa=sqrt(1-((sin_alfa)**2));
                cos_alfa2=(cos_alfa)**2;        
                cos_2sigma_m=cos_sigma-((2*sin(Ua)*sin(Ub))/cos_alfa2);
                C=(f/16)*cos_alfa2*((4+f*(4-3*cos_alfa2)));
                L=delta_lambda+(1-C)*f*sin_alfa*(sigma+C*sin_sigma*(cos_2sigma_m+C*(cos_sigma*(-1+2*(cos_2sigma_m)**2))));
                k=abs(l-L)
    
            u2=((a**2-b**2)/b**2)*cos_alfa2;
            A=1+(u2/16384)*(4096+u2*(-768+u2*(320-175*u2)));
            B=(u2/1024)*(256+u2*(-128+u2*(74-47*u2)));
            delta_sigma=(B*sin_sigma)*(cos_2sigma_m+(1/4)*B*(cos_sigma*(-1+2*((cos_2sigma_m)**2))-(1/6)*B*cos_2sigma_m*(-3+4*((sin_sigma)**2)*(-3+4*((cos_2sigma_m)**2)))))
            S=b*A*(sigma-delta_sigma)
        odl2.append(S)
        print(S)
    suma=sum(odl2)
    print(suma)
    odl2.insert(0,0)
    
    ODL2D=numpy.cumsum(odl2)
    ax1=plt.subplot(111)
    pylab.plot(ODL2D,el)
    ax1.set_ylabel("Wysokosc[m]")
    ax1.set_xlabel("Odleglosc[m]")
    plt.savefig('odleglosc-wysokosc')
    plt.show()
    
    odl2.remove(0)
    
    Odcinki_m=odl2
    
    #Przewyzszenia na odcinkach
    
    przewyzszenia=[]
    il=len(el)
    for p in range(len(el)):
        if p+1>=il:
            break
        else:
            aa =el[(p+1)] - el[p]
            przewyzszenia.append(aa)
    Przewyzszenie_suma=sum(przewyzszenia)
    
    przewyzszenia_góra=[]
    przewyzszenia_dół=[]
    
    wysokosc_max=max(el)
    wysokosc_min=min(el)
    
    for i in przewyzszenia:
        if i == 0:
            pass
        elif i>0:
            przewyzszenia_góra.append(i)
        elif i<0:
            przewyzszenia_dół.append(i)
    
    Przewyzszenia_góra_suma=sum(przewyzszenia_góra)
    Przewyzszenia_dół_suma=sum(przewyzszenia_dół)
    
            
    #CZAS
    
    d=[]
    x=len(dates)
    for i in range(len(dates)):
        if i+1>=x:
            break
        else:
            a = dates[i+1] - dates[i]
            a2 = a.total_seconds()
            d.append(a2)
            e=sum(d)
            czas_ostateczny = timedelta(seconds=e)
            
    
    #NACHYLENIE w stopniach
    
    Nachylenie=[]
    
    for (m,h) in zip (Odcinki_m,przewyzszenia):
        if m==0 and h==0:
            nach=0
        else:
            nach=degrees(atan((h/m)))
        Nachylenie.append(nach)
        
    HARDCORE=max(Nachylenie)
    print(HARDCORE)
    #SKOSNA
    
    Skosna=[]
    for (u,o) in zip (Nachylenie, Odcinki_m):
        if u == 0 or o==0:
            skosna=0
        else:
            skosna=o/cos(radians(u))
        Skosna.append(skosna)
    Skosna_suma=sum(Skosna)
    print(Skosna_suma)
    
    #PRĘDKOŚĆ
    
    predkosc=[]
    for (m,s) in zip(Odcinki_m,d):
        if s==0 or m==0:
            pred=0
        else:
            pred=m/s
        predkosc.append(pred)
    
    sr_predkosc=(sum(Skosna)/sum(d))/(1000/3600)

        
    ODC1 = range(1,1539)
    ODC2 = ODC1[1:]
    
    # Zapisywanie wynikow  
    plik=open('wyniki.txt', 'w') # Otwieranie pliku
    plik.write('{:^15}{:^15}{:^15}{:^15}{:^15}{:^15}'.format('Odcinek','Odległosc_poz','Odległosc_s','Czas[s]','Prędkosc[m/s]','Nachylenie[st]'))
    plik.write('\n')
    for (i,j,w,k,s,o,p) in zip (ODC1,ODC2,Odcinki_m,Skosna,d,predkosc,Nachylenie):#petla ktora bedzie zapisywala wszystkie wartosci liczb E N U
        odc=('{}-{}'.format(i,j))
        E1 = float(w)
        K1 = float(k)
        N1 = float(s)
        U1 = float(o)
        P1 = float(p)
        plik.write('\n{:^15}{:15.3f}{:15.3f}{:15.3f}{:15.3f}{:15.3f}'.format(odc,E1,K1,N1,U1,P1)) #3 miejsca po przecinku
    plik.write('\n')
    plik.close
    

class MapViewApp(App):
    def build(self):
        return TestForm()
    #pass
    
if __name__ == '__main__':
    MapViewApp().run()
